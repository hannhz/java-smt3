public class Test {
    public static void main(String args[]) {
        Siswa anak= new Siswa();
        anak.setNrp(456);
        System.out.println(anak.getNrp());
         
    }
}

