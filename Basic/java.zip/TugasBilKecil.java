import javax.swing.JOptionPane;

public class TugasBilKecil {
    public static void main(String[] args) {
        BilanganTerkecil bilanganTerkecil = new BilanganTerkecil();
        bilanganTerkecil.inputBilangan();
    }
}
