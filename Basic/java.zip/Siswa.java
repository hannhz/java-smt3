/* @author VivoBook
 */
public class Siswa {
    
    public int nrp;
    
    public void Siswa(int i) {
        nrp=i;
    }
    
    public void setNrp(int i){
        nrp=i;
    }
    
    public int getNrp(){
        return nrp;
    }
    
    /**int nrp;
    
    public void setNrp(int i){
        nrp=i;**/
    
    }
        





