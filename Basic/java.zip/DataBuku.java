public class DataBuku{
    public static void main (String args[]){
        Buku book1= new Buku();
        book1.setNama("petualangan siera");
        book1.setNo(27839471);
        book1.setTahun(2010);
        
        book1.infoBuku();
        
    }
}