public class Assign {
    public static void main(String args[]) {
       boolean b = true;
       System.out.println("Value b=" +b);
       
       char c = 'c';
       System.out.println("Value c=" + c);
       
       byte bt = 10;
       System.out.println("Value bt=" +bt);
       
       short s = 20;
       System.out.println("Value s =" +s);
        
       int i = 30;
       System.out.println("Value i=" +i);
       
       long l = 40L;
       System.out.println("Value l = " + l);
       
       float f = 3.14F;
       System.out.println("Value f = " + f);
       
       double d = 3.14;
       System.out.println("Value d = " + d);
       
    }
}
