class Conditional{
    public static void main(String args[]){
        int x = 0;
        boolean isEven = false;
        System.out.println("x = "+x);
        x = isEven ? 4 : 7;
        System.out.println("x = "+ x);
    }
}