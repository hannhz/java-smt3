public class DefaultValue {
    static boolean b;
    static char c;
    static byte bt;
    static short s;
    static int i;
    static long l;
    static float f;
    static double d;
        public static void main(String args[]) {
            System.out.println("Default value b = " + b);
            System.out.println("Default value c = " + c);
            System.out.println("Default value bt = " + bt);
            System.out.println("Default value s = " + s);
            System.out.println("Default value i = " + i);
            System.out.println("Default value l = " + l);
            System.out.println("Default value f = " + f);
            System.out.println("Default value d = " + d);
        }
}