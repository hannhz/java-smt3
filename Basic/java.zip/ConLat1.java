import javax.swing.JOptionPane;
public class ConLat1{
    public static void main (String args[]){
        int angka, bilangan;
        String str = JOptionPane.showInputDialog("Masukkan angka :");
        angka = Integer.parseInt(str);
        
    }
}