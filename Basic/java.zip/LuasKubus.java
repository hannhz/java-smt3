public class LuasKubus{
	public static void main(String[] args){
		int sisi = 5;
		int luas = sisi*sisi*sisi;
		System.out.println("luas kubus = " + luas);
	
	}
}