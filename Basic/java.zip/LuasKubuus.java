public class LuasKubuus{
	public static void main(String[] args){
		double r = 5;
		double luas = Math.PI * r * r;
		double keliling = 2 * Math.PI * r;
		System.out.println("Luas = " + luas);
		System.out.println("Keliling = " + keliling);
	}
}
